/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1;

/**
 *
 * @author asus_
 */
public class silver extends rekening{
    
    public silver(String nama) {
        super("silver", 25000000, false, nama);
    }
    
}
