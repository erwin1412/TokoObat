/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihanuasno3;

/**
 *
 * @author asus_
 */
public class LATIHANUASNO3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        frame f=new frame();
        f.setSize(820, 640);
        f.setVisible(true);
    }
    
}
