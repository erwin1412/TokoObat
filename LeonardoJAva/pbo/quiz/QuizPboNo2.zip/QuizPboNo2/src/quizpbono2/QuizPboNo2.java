
package quizpbono2;

public class QuizPboNo2 {

    public static void main(String[] args) {
        new frame1().setVisible(true);
    }
    
}
