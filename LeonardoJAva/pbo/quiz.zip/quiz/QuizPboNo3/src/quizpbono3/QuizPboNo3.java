
package quizpbono3;

public class QuizPboNo3 {

    public static void main(String[] args) {
        new frame1().setVisible(true);
    }
    
}
