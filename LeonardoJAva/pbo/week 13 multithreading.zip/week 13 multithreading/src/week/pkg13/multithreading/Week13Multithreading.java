/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package week.pkg13.multithreading;

/**
 *
 * @author B204
 */
public class Week13Multithreading {
    
    public static void main(String[] args) {
        new Jframe().setVisible(true);
    }
    
}
